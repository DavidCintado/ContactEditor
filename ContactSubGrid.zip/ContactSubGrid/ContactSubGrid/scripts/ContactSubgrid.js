﻿var clientURL = parent.Xrm.Page.context.getClientUrl();
var prefConMethOptions = GetMetadata();
var ENGLISH = "1033";
var SPANISH = "3082";
var userLang = ENGLISH;


function OnLoad() {
    GetMetadata();
    GetContact(SearchCompleted);
}

function GetMetadata() {
    GetMetadataByName("contact", "preferredcontactmethodcode", CreateSelect);
}

function CreateSelect(data) {
    if (data && data.OptionSet.Options.length > 0) {
        userLang = data.OptionSet.Options[0].Label.UserLocalizedLabel.LanguageCode;

        for (var i = 0; i < data.OptionSet.Options.length; i++) {

            prefConMethOptions = prefConMethOptions + "<option value='" + data.OptionSet.Options[i].Value +
                "'>" + data.OptionSet.Options[i].Label.UserLocalizedLabel.Label + "</option>";
        }
    }
}

function GetMetadataByName(entityLogName, attLogName, successCallback)
{
    var apiVersion = parent.Xrm.Page.context.getVersion();
    var req = new XMLHttpRequest();

    var query = "/api/data/v" + apiVersion + "/EntityDefinitions(LogicalName='" + entityLogName + "')/Attributes(LogicalName='" + attLogName + "')/Microsoft.Dynamics.CRM.PicklistAttributeMetadata?$select=LogicalName&$expand=OptionSet($select=Options),GlobalOptionSet($select=Options)";
    req.open("GET", encodeURI(clientURL + query), true);
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json;charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.onreadystatechange = function () {
        if (this.readyState == 4) {
            req.onreadystatechange = null;
            if (this.status == 200) {
                var data = JSON.parse(this.response);
                successCallback(data);
            }
        }
    }
    req.send();
}

function GetContact(successCallback) {
    var accountId = parent.Xrm.Page.data.entity.getId().replace("{", "").replace("}", "");
    var apiVersion = parent.Xrm.Page.context.getVersion();
    var req = new XMLHttpRequest();

    var query = "/api/data/v" + apiVersion + "/contacts?$select=firstname,lastname,fullname,emailaddress1,preferredcontactmethodcode&$filter=_accountid_value eq " + accountId;
    req.open("GET", encodeURI(clientURL + query), true);
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json;charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.onreadystatechange = function () {
        if (this.readyState == 4) {
            req.onreadystatechange = null;
            if (this.status == 200) {
                var data = JSON.parse(this.response);
                successCallback(data, "", "");
            }
        }
        else {
        }
    }
    req.send();
}


function SearchCompleted(data, textStatus, XmlHttpRequest) {

    if (data && data.value.length > 0) {
        for (var i = 0; i < data.value.length; i++) {
            //Generates Contact detail rows
            CreateNewRow(data.value[i]);
        }
    }
    else {
        alert("No Contact record(s) retrieved.");
    }
}

//new row in the table, add button in the row
function CreateNewRow(contact) {

    if (contact) {
        //Hide the "Empty Message" row
        $("TR.EmptyRow").hide();

        //New row
        var row = $("<tr/>");
        row.append($("<td><output type='text' id='FullName' style='width: 100px;'  /></td>"));
        row.append($("<td><input type='text' id='FirstName' style='width: 100px;border-style:none !important;' /></td>"));
        row.append($("<td><input type='text' id='LastName' style='width: 100px;border-style:none' /></td>"));
        row.append($("<td><input type='text' id='EMailAddress1' style='width: 150px;border-style:none' readonly='true' /></td>"));
        row.append($("<td><select id='PreferredContactMethod' style='width: 150px; border-style:none'>" + prefConMethOptions + "</select></td>"));
        row.append($("<td><input type='button' id='SaveButton' title='Click to save changes to the record.' value='Save' /></td>"));
        row.append($("<td  style='display: none'><input type='text' id='ContactId'  /></td>"));
        $("#ContactTableBody").append(row);

        //Set fields from contact
        if (contact.contactid) {
            row.find("#ContactId").attr("value", contact.contactid);
        }
        if (contact.fullname) {
            row.find("#FullName").html("<a style='text-decoration: none; decoration: none' target=\"_blank\" href=\"" +
                               clientURL + "/main.aspx?etn=contact&id=%7b" + contact.contactid +
                               "%7d&pagetype=entityrecord\">" + contact.fullname + "</a>");
        }
        if (contact.firstname)
            row.find("#FirstName").attr("value", contact.firstname);
        if (contact.lastname)
            row.find("#LastName").attr("value", contact.lastname);
        if (contact.emailaddress1)
            row.find("#EMailAddress1").attr("value", contact.emailaddress1);
        if(contact.preferredcontactmethodcode)
            row.find("#PreferredContactMethod").val(contact.preferredcontactmethodcode);

        //Wire up the SaveButton event handler
        row.find("#SaveButton").click(function () {
            var contactRow = $(this).parent().parent();
            TMP_ROW = contactRow;
            $(":button").prop('disabled', true);
            var contactObject = ExtractContactFromRow(contactRow);

            if (contactObject.contactid && contactObject.contactid != null) {
                //Update the CRM record
                updateRecord(contactObject.contactid, contactObject);
            }
        });
    }
}

//Extract Contact information from row
function ExtractContactFromRow(row) {
    var contact = new Object();

    if (row.find("#ContactId").val()) {

        contact.contactid = row.find("#ContactId").val();
    }

    contact.firstname = row.find("#FirstName").val();
    contact.lastname = row.find("#LastName").val();
    contact.preferredcontactmethod = row.find("#PreferredContactMethod").val();

    return contact;
}

// Update record
function updateRecord(id, entityObject) {
    //id is required
    if (!id) {
        alert("record id is required.");
        return;
    }
    // Last Name y required
    if (!entityObject.lastname || entityObject.lastname == "")
    {
        alert("Last Name is required.");
        ContactUpdateInCompleted();
        return;
    }
    
    UpdateContact(id, entityObject); 
}

// Update contact record
function UpdateContact(id, contact) {
    var clientURL = parent.Xrm.Page.context.getClientUrl();
    var apiVersion = parent.Xrm.Page.context.getVersion();
    var contactId = id;
    var entityType = "contacts";

    var contactTobeUpdated = {};
    contactTobeUpdated["firstname"] = contact.firstname;
    contactTobeUpdated["lastname"] = contact.lastname;
    contactTobeUpdated["preferredcontactmethodcode"] = contact.preferredcontactmethod;
    UpdateEntity(clientURL, contactId, entityType, contactTobeUpdated, apiVersion);
}

// Update entity by web api
function UpdateEntity(clientURL, entityId, entityType, entityTobeUpdated, apiVersion) {
    var req = new XMLHttpRequest();
    req.open('PATCH', clientURL + "/api/data/v"+apiVersion+"/" + entityType + "(" + entityId + ")", true);
    req.setRequestHeader("Content-type", "application/json");
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");

    req.onreadystatechange = function () {
        if (this.readyState == 4 /* complete */) {
            req.onreadystatechange = null;
            if (this.status == 204) {
                ContactUpdateCompleted();
            }
            else {
                var error = JSON.parse(this.response).error;
                alert(error.message);
            }
        }
    };
    req.send(JSON.stringify(entityTobeUpdated));
}

//Callback
function ContactUpdateCompleted() {
    TMP_ROW = null;
    $(":button").removeAttr("disabled");
    alert("Update complete.");
}

// Enable button
function ContactUpdateInCompleted() {

    TMP_ROW = null;
    $(":button").removeAttr("disabled");
}

// Create new contact button
function NewButton_onclick() {
    var accountId = parent.Xrm.Page.data.entity.getId()

    var accountName = parent.Xrm.Page.getAttribute("name").getValue();
    var parentAccount = { entityType: "account", id: accountId, name: accountName };
    var parameters = {};
    parameters.parentcustomerid = accountId;
    parameters.parentcustomeridname = accountName;
    parameters.parentcustomeridtype = "account";
    parent.Xrm.Utility.openQuickCreate("contact", null, parameters);
}